<!doctype html>
<html lang="hu">
<head>
    <title>Enaplo</title>
</head>
<body>
    <h1>Osztályzatok</h1>
    <hr>
    <ul>
        <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($grade->grade); ?> (x<?php echo e($grade->weight); ?>) [<?php echo e($grade->comment); ?>]
                <ul>
                    <li><?php echo e($grade->student->name); ?></li>
                </ul>
            </li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\vue-gyak-enaplo\ENaploBackend\resources\views/grades.blade.php ENDPATH**/ ?>